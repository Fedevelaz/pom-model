%
% Elabor�:  Lic. Mart�n Alfredo Terrazas Silva
%           Universidad de Guadalajara
%           2013
%
% El programa anima_2kTxz lee, grafica y guarda las im�genes de los 
% cortes verticales en el plano xz de Temperatura, Dendidad y otras
% variables. Adem�s de los archivos convencionales, que se enlistan a 
% continuaci�n este programa necesita de un �ndice io sobre el cual se 
% realizar� el corte, el cu�l se define durante el programa.
%
%                         fort.2000 + jo*10 + var
%                         params.out
%                         sigma.out
%                         bath.out
%
% Los �ltimos tres archivos se utilizan en las funciones rearparams.f 
% y readbath.f.
%



clear all; clc

%-------------------- Variables Globales ---------------------
global IM JM KB DTE DTI DAYS PRTD1
global L3D L2D TM X Y Z 
global ZZ DZ DZZ DELX DELY dxdy A


%------------------------ Read Params ------------------------
readparams()
jo=24; % �ndice sobre el eje x de donde se tomar� el corte

%--------------------- Variables ---------------------
LXZ=IM*KB;  %plano xz

var=4;   % Habilitar para graficar Temperatura
%var=5;  % Habilitar para graficar Densidad

Tmax=10*24+1;  % Horas*24+1

%------------------------ Batimetr�a --------------------------
H=-readbath(); 
h=H(:,jo); % De la matriz H toma todos los y que est�n sobre jo


for k=1:length(h); 
    zx(:,k)=-ZZ.*h(k); % Se obtienen los datos del plano yz 
end

x=repmat(X,KB,1);


%-------------------- Lectura de Variables ---------------------

No=num2str(2000 + jo*10 + var); 
fidxz = fopen(['fort.' No],'rb','a');

for k=1:Tmax
    er  =fread(fidxz ,  1,'float32'); % acomoda los errores en columna
    va  =fread(fidxz ,LXZ,'float32');  % acomoda los errores en columna
    er  =fread(fidxz ,  1,'float32');  % acomoda los errores en columna
    
    if length(va)<LXZ; break; end
      
    va(va<1)=NaN;
    VAA(:,:,k)=reshape(va,IM,KB);  
    
%    ---------------------- Graficado ----------------------------
    clf
    subplot 211
    contourf(x/1000,-zx,squeeze(VAA(:,:,k))',10); 
    colorbar; 
    caxis([14 21])
    axis([[X(1) X(IM)]./1000 -500 0])
    xlabel('Distancia [km]','FontName','Arial','FontSize', 12);
    
    drawnow
    
    if k<10
        saveas( ylabel('Profundidad [m]','FontName','Arial','FontSize', 12), sprintf('img00%d.jpg', k)) 
    elseif k<100
         saveas( ylabel('Profundidad [m]','FontName','Arial','FontSize', 12), sprintf('img0%d.jpg', k))  
    else
         saveas( ylabel('Profundidad [m]','FontName','Arial','FontSize', 12), sprintf('img%d.jpg', k))  
    end

end

fclose(fidxz);


