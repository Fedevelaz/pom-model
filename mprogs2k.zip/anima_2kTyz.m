%
% Elabor�:  Lic. Mart�n Alfredo Terrazas Silva
%           Universidad de Guadalajara
%           2013
%
% El programa anima_2kTyz lee, grafica y guarda las im�genes de los 
% cortes verticales en el plano yz de Temperatura, Dendidad y otras
% variables. Adem�s de los archivos convencionales, que se enlistan a 
% continuaci�n este programa necesita de un �ndice io sobre el cual se 
% realizar� el corte, el cu�l se define durante el programa.
%
%                         fort.3000 + io*10 + var
%                         params.out
%                         sigma.out
%                         bath.out
%
% Los �ltimos tres archivos se utilizan en las funciones rearparams.f 
% y readbath.f.
%



clear all; clc

%-------------------- Variables Globales ---------------------
global IM JM KB DTE DTI DAYS PRTD1
global L3D L2D TM X Y Z 
global ZZ DZ DZZ DELX DELY dxdy A


%------------------------ Read Params ------------------------
readparams()
io=32; % �ndice sobre el eje x de donde se tomar� el corte


%------------------------ Variables --------------------------

LYZ=JM*KB;     % Plano yz
    
var=4;   % Habilitar para graficar Temperatura
%var=5;  % Habilitar para graficar Densidad


Tmax=10*24+1;  % Horas*24+1


%------------------------ Batimetr�a --------------------------
H=-readbath(); 
h=H(io,:); % De la matriz H toma todos los y que est�n sobre io


for k=1:length(h); 
    zy(:,k)=-ZZ.*h(k); % Se obtienen los datos del plano yz 
end

y=repmat(Y,KB,1);


%-------------------- Lectura de Variables ---------------------

No=num2str(3000 + io*10 + var); 
fidyz = fopen(['fort.' No],'rb','a');

for k=1:Tmax
    er  =fread(fidyz ,  1,'float32'); 
    va  =fread(fidyz ,LYZ,'float32');  
    er  =fread(fidyz ,  1,'float32');  
    
    if length(va)<LYZ; break; end
    
    va(va<1)=NaN;    
    VAA(:,:,k)=reshape(va,JM,KB);  

%    ---------------------- Graficado ----------------------------
    clf
    subplot 211
    contourf(y/1000,-zy,squeeze(VAA(:,:,k))',10); 
    colorbar; 
    caxis([14 21])
    xlabel('Distancia [km]','FontName','Arial','FontSize', 12);
    
    drawnow
    
    if k<10
        saveas( ylabel('Profundidad [m]','FontName','Arial','FontSize', 12), sprintf('img00%d.jpg', k)) 
    elseif k<100
         saveas( ylabel('Profundidad [m]','FontName','Arial','FontSize', 12), sprintf('img0%d.jpg', k))  
    else
         saveas( ylabel('Profundidad [m]','FontName','Arial','FontSize', 12), sprintf('img%d.jpg', k))  
    end

end 

fclose(fidyz);

