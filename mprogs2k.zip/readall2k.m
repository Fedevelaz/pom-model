%
% Elabor�:  Lic. Mart�n Alfredo Terrazas Silva
%           Universidad de Guadalajara
%           2013
%
% El programa readsealevel.m, utiliza archivos de salida del modelo 
% pom2k para leer, graficar y guardar las im�genes que muestran el
% nivel del mar. Necesita los siguientes archivos para correr:
%
%                         fort.101
%                         fort.102
%                         fort.103
%                         params.out
%                         sigma.out
%                         bath.out
%
% Los �ltimos tres archivos se utilizan en las funciones rearparams.f 
% y readbath.f. 

clc; clear all;

%-------------- Variables Globales ---------------
global IM JM KB DTE DTI DAYS PRTD1
global L3D L2D TM X Y Z 
global ZZ DZ DZZ DELX DELY dxdy A



%------------------ Read Params ------------------
readparams()
%------------------- Read Bath ------------------- 

Tmax=DAYS*24+1;
x=[1:IM]*DELX;
y=[1:JM]*DELY;
[x, y]=meshgrid(x/1000,y/1000);
is=5:5:IM; js=5:5:JM;

H=readbath();

%--------------- Read Eta, UA, VA --------------- 

fid = fopen('fort.1001','rb','a');
fidu = fopen('fort.1002','rb','a');
fidv = fopen('fort.1003','rb','a');

for k=1:Tmax
    er = fread(fid , 1 ,'float32');
    el = fread(fid ,L2D,'float32');
    er = fread(fid , 1 ,'float32');

    er = fread(fidu , 1 ,'float32');
    ua = fread(fidu ,L2D,'float32');
    er = fread(fidu , 1 ,'float32');

    er = fread(fidv , 1 ,'float32');
    va = fread(fidv ,L2D,'float32');
    er = fread(fidv , 1 ,'float32');
    
    if length(el)<L2D; break; end
    if length(ua)<L2D; break; end
    if length(va)<L2D; break; end
       
    if k>1; el(el==0)=NaN; end
    
    eta(:,:,k)=reshape(el,IM,JM);
    UA(:,:,k)=reshape(ua,IM,JM);
    VA(:,:,k)=reshape(va,IM,JM);
    
    clf
    surf(x',y',eta(:,:,k))         %Nivel del mar
    colorbar;
    shading interp
    hold on
    caxis([-1 1]*0.5)
    axis([0 5E+1 0 4E+1 -500 100])
    drawnow
    xlabel('Distancia [km]','FontName','Arial','FontSize', 12);
    ylabel('Distancia [km]','FontName','Arial','FontSize', 12);
    zlabel('Profundidad [m]','FontName','Arial','FontSize', 12);
   
    quiver3(x(js,is)',y(js,is)',eta(is,js,k),UA(is,js,k),VA(is,js,k),UA(is,js,k)*0,'k')  %Vectores de velocidad

    if k<10
        saveas(surf(x',y',H), sprintf('img00%d.jpg', k))  %Seamount
    elseif k<100
         saveas(surf(x',y',H), sprintf('img0%d.jpg', k))  %Seamount
    else
         saveas(surf(x',y',H), sprintf('img%d.jpg', k))   %Seamount
    end
    
end
fclose(fid);
fclose(fidu);
fclose(fidv);   